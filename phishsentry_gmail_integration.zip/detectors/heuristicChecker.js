export function runHeuristics(emailText) {
  const findings = [];

  const redFlags = [
    { pattern: /https?:\/\/\d{1,3}(\.\d{1,3}){3}/g, label: "IP-based URL" },
    { pattern: /reply-to:.*@.*\.(tk|xyz|ml|ga)/gi, label: "Suspicious TLD" },
    { pattern: /base64/i, label: "Base64 usage" },
    { pattern: /urgent|verify|suspended|immediately|click here/gi, label: "Urgency keywords" }
  ];

  for (const rule of redFlags) {
    if (rule.pattern.test(emailText)) {
      findings.push(rule.label);
    }
  }

  return findings;
}