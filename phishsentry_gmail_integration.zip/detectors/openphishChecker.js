export function checkOpenPhish(emailText, openPhishList) {
  return openPhishList.filter(domain =>
    emailText.toLowerCase().includes(domain.toLowerCase())
  );
}