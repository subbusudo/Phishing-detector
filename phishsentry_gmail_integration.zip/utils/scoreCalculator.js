export function calculateScore(openPhishHits, heuristicHits) {
  let score = 0;
  score += openPhishHits.length * 5;
  score += heuristicHits.length * 2;
  return Math.min(score, 10);
}